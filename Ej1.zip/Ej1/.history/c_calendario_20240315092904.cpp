#include <iostream>

#include "c_calendario.h"

using namespace std;

Calendario::Calendario(){
    dia_i = 0;
    duracion = 0;
    año = 0;
    mes = 0;
    bisiesto = false;
}
bool Calendario::cal_bisiesto(){
    if (año%4==0){
        if (año%100==0){
            if (año%400==0){
                return true;
            }
            return false;
        }
        return true;
    } else {
        return false;
    }
    
}

int Calendario::long_mes(){
    if (mes==1 || mes==3 || mes==5 || mes== 7 || mes==8 || mes==10 || mes==12){
        return 31;
    } else if (mes==2){
        if (bisiesto){
            return 29;
        } else {
            return 28;
        }
    } else {
        return 30;
    }
}
void Calendario::imp_cal(){
    bisiesto = cal_bisiesto();
    duracion = long_mes();

    cout << "\x1B[31m" << "\n\n\tLu\tMa\tMi\tJu\tVi\tSa\tDo" << "\x1B[m \n";
    int pos{0};
    /*switch (dia_i) {
    case 1:
         code 
        break;
    
    default:
        break;
    }*/
    for (;pos < dia_i; pos++){
        cout << "\t";
    }
    int i{0};
    while (i < duracion) {
        
        
        if (pos % 7 == 0){
            cout << "\n";
        }
        i++;
        pos++;
        cout << "\t" << i; // << " " << pos % 7;

    }
    /*
    for (int i = 0; i < duracion; i++){
        cout << "\t" << i;
    }*/
    
     cout << "\n";

}