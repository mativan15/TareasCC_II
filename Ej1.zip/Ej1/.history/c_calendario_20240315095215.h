#include <iostream>
using namespace std;

class Calendario {public:
    int dia_i;
    int duracion;
    int año;
    int mes;
    bool bisiesto;

    Calendario();
    bool cal_bisiesto();
    int long_mes();
    void imp_cal();
    int cal_dia_i();
};