#include <iostream>
#include "head.h"

int main(){
    iniciar();
    return 0;
}